#include "mainwindow.h"

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow{parent}
{
    QGridLayout* layout = new QGridLayout;
    text = new QPlainTextEdit();
    text->setReadOnly(true);
    lwUsers = new QListWidget();
    layout->addWidget(text, 0,1);
    layout->addWidget(lwUsers,0,2);
    QWidget *widhet = new QWidget();
    widhet->setLayout(layout);
    setCentralWidget(widhet);


}
