#include "sslserver.h"
using namespace server;

SslServer::SslServer(QString IP, int port) {
    serverIP = IP;
    serverPort = port;
    window = new MainWindow();
    window->setWindowTitle("IP: " + serverIP + " Port: " + QString::number(serverPort) + " Clients connected: 0");
}


bool SslServer::startServer() {
    if (listen(QHostAddress(serverIP), serverPort)) {

        window->text->setPlaceholderText("Server start on port:" + QString::number(serverPort));
        emit started();
    } else {
        window->text->appendPlainText("Cant satrt server on port:"+ QString::number(serverPort));
        emit error(Error::SERVER_START_ERROR);
        return false;
    }
    return true;
}
void SslServer::incomingConnection(qintptr handle) {
    clientConnection = new ClientConnection(window);

    if (clientConnection->setSocket(handle))
    {
        connect(clientConnection, SIGNAL(sendnames(QString)), SLOT(sendnames(QString)) );
        connect(clientConnection, SIGNAL(delname(QString)), SLOT(delname(QString)));
        connect(clientConnection, SIGNAL(changename(QString,QString)), SLOT(changename(QString, QString)));
        connect(clientConnection, SIGNAL(sendmessage(QString,QString)), SLOT(sendmessage(QString, QString)));
        connect(clientConnection, SIGNAL(sendstatus(QString,QString)), SLOT(sendstatus(QString, QString)));
        _users.push_back(clientConnection);
        QThread* threadForClient = new QThread();
        clientConnection->moveToThread(threadForClient);
        threadForClient->start();
    } else {
        window->text->appendPlainText("socket setup error;");
        delete clientConnection;
        emit error(Error::SOCKET_SETUP_ERROR);
    }

}

void SslServer::sendnames(QString name)
{
    if (_users.length() <= 1)
        return;
    ClientConnection* sendto;
    QStringList l;
    for (int i =0; i <_users.length(); i++){
        if (_users[i]->_username == name)
        {
            sendto = _users[i];
        }
        else
        {
            l << _users[i]->_username + "$" + _users[i]->_timeConnected.toString() + "$" + _users[i]->_userStatus;
            QByteArray block;
            QDataStream out(&block, QIODevice::WriteOnly);
            out << (quint16)0;
            out << comUsersOnline;
            QString s;
            s += _users[_users.size() - 1]->_username + "$" + _users[_users.size() - 1]->_timeConnected.toString("HH:mm:ss") + "$" + _users[_users.size() - 1]->_userStatus;
            out << s;
            out.device()->seek(0);
            out << (quint16)(block.size() - sizeof(quint16));
            _users[i]->socket->write(block);
        }

    }
    QByteArray block;
    QDataStream out(&block, QIODevice::WriteOnly);
    out << (quint16)0;
    out << comUsersOnline;
    QString s;
    for (int i = 0; i < l.length(); ++i)
        if (l.at(i) != name)
            s += l.at(i)+(QString)",";
    s.remove(s.length()-1, 1);
    out << s;
    out.device()->seek(0);
    out << (quint16)(block.size() - sizeof(quint16));
    sendto->socket->write(block);
}

void SslServer::delname(QString name)
{
    int index;
    for (int i =0; i <_users.length(); i++){
        if (_users[i]->_username != name)
        {
            QByteArray block;
            QDataStream out(&block, QIODevice::WriteOnly);
            out << (quint16)0;
            out << comUserLeft;
            QString s;
            s += name;
            out << s;
            out.device()->seek(0);
            out << (quint16)(block.size() - sizeof(quint16));
            _users[i]->socket->write(block);
        }
        else
        {
            index = i;
        }
    }
    _users.removeAt(index);
}

void SslServer::changename(QString name, QString n_name)
{
    for (int i =0; i <_users.length(); i++)
    {
        if (_users[i]->_username != name)
        {
            QByteArray block;
            QDataStream out(&block, QIODevice::WriteOnly);
            out << (quint16)0;
            out << comUserRename;
            QString s;
            s += name +(QString)",";
            s += n_name;
            out << s;
            out.device()->seek(0);
            out << (quint16)(block.size() - sizeof(quint16));
            _users[i]->socket->write(block);
        }
    }
}

void SslServer::sendmessage(QString name, QString message)
{
    for (int i =0; i <_users.length(); i++)
    {
        if (_users[i]->_username != name)
        {
            QByteArray block;
            QDataStream out(&block, QIODevice::WriteOnly);
            out << (quint16)0;
            out << comMessageToUsers;
            QString s;
            s += name +(QString)"✉";
            s += message;
            out << s;
            out.device()->seek(0);
            out << (quint16)(block.size() - sizeof(quint16));
            _users[i]->socket->write(block);
        }
    }
}

void SslServer::sendstatus(QString name, QString status)
{
    for (int i =0; i <_users.length(); i++)
    {
        if (_users[i]->_username != name)
        {
            QByteArray block;
            QDataStream out(&block, QIODevice::WriteOnly);
            out << (quint16)0;
            out << comUserStatus;
            QString s;
            s += name +(QString)"✉";
            s += status;
            out << s;
            out.device()->seek(0);
            out << (quint16)(block.size() - sizeof(quint16));
            _users[i]->socket->write(block);
        }
    }
}
