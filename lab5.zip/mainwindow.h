#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QPlainTextEdit>
#include <QListWidget>
#include <QGridLayout>
class MainWindow : public QMainWindow
{
    Q_OBJECT
public:
    explicit MainWindow(QWidget *parent = nullptr);
    QPlainTextEdit*  text;
    QListWidget* lwUsers;
    int clientsConnected = 0;

};

#endif // MAINWINDOW_H
