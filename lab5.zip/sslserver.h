#ifndef SSLSERVER_H
#define SSLSERVER_H

#include <QTcpServer>
#include <QDebug>
#include <QThread>
#include "type.h"
#include "clientconnection.h"
#include "mainwindow.h"
#include "gost.h"

namespace server {

    class SslServer : public QTcpServer {
        Q_OBJECT
    public:
        SslServer(QString IP, int port);
        bool startServer();
        MainWindow* window;
    signals:
        void error(Error errorCode);
        void started();
    private slots:
        void sendnames(QString name);
        void delname(QString name);
        void changename(QString name, QString n_name);
        void sendmessage(QString name, QString message);
        void sendstatus(QString name, QString status);
    private:
        QString serverIP;
        int serverPort;
        void incomingConnection(qintptr handle);
        ClientConnection* clientConnection;
        QList<ClientConnection*> _users;
        enum arguments{
            comAutchReq = (quint8)1,
            comUsersOnline = (quint8)2,
            comUserRename = (quint8)3,
            comUserLeft = (quint8)4,
            comMessageToAll = (quint8)5,
            comMessageToUsers = (quint8)6,
            comUserStatus = (quint8)7,
            comPrivateServerMessage = (quint8)8,
            comAutchSuccess = (quint8)9,
            comErrNameInvalid = (quint8)201,
            comErrNameUsed = (quint8)202
        };

    };
}

#endif // SSLSERVER_H
